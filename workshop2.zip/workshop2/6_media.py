import streamlit as st


## image from local
from PIL import Image
image = Image.open("pythoncoding.jpg")
st.image(image, caption="This image is from local")

## image from internet
st.image("https://logos-download.com/wp-content/uploads/2016/10/Python_logo_wordmark.png",  caption="This image is from internet")


## video from local
video_file = open("whale_vid.mp4", "rb")
video_bytes = video_file.read()
st.video(video_bytes)

## video from internet
st.video("https://youtu.be/yjki-9Pthh0")