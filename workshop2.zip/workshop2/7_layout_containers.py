import streamlit as st
import numpy as np


## sidebar
# Using "with" notation
with st.sidebar:
    add_radio = st.radio(
        "Choose a shipping method",
        ("Standard (5-15 days)", "Express (2-5 days)")
    )
    

    
## columns
col1, col2, col3 = st.columns(3)

with col1:
    st.header("POSLaju")
    st.image("https://easyparcel.com/blog/my/assets/uploads/2020/01/poslaju-logo-vector-720x340.png")

with col2:
    st.header("Shopee Express")
    st.image("https://www.akacanvas.com/wp-content/uploads/2020/06/shopee-express-logo.png")

with col3:
    st.header("DHL")
    st.image("https://logos-download.com/wp-content/uploads/2016/07/DHL_logo.png")
    
    
    
## container
with st.container():
    st.write("This is inside the container")

    # You can call any Streamlit command, including custom components:
    st.bar_chart(np.random.randn(50, 3))

st.write("This is outside the container")