import streamlit as st

## error box
st.error('🚨 This is an error')

## warning box
st.warning('⚠️ This is a warning')

## info box
st.info('ℹ️ This is a purely informational message')

## success box
st.success('✅ This is a success message!')

## progress bar
import time

my_bar = st.progress(0)

for percent_complete in range(100):
     time.sleep(0.1)
     my_bar.progress(percent_complete + 1)
    

## spinner
with st.spinner('Wait for it...'):
    time.sleep(5)
st.success('Done!')


## balloons
st.balloons()


## snowflakes
st.snow()



