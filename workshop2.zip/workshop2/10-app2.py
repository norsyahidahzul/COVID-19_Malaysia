import streamlit as st


# title
st.title("My favorites")

# 3 columns that display your favorite songs from youtube





# 3 columns that display your photo of favorite foods.




# balloon or snowflake



# caption by your name
st.caption("Developed by Wawiwu")