import streamlit as st


# title


# height


# weight


# calculate bmi


# message alert
# follow classifation below
# http://www.myhealth.gov.my/indeks-jisim-tubuh-ijt/






# caption
