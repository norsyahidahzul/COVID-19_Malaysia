import streamlit as st
import seaborn as sns
import pandas as pd
import numpy as np


# load titanic data from seaborn
# Source: https://github.com/mwaskom/seaborn-data/blob/master/taxis.csv
df1 = sns.load_dataset('taxis')

# line chart by tip


# area chart by total


# area chart by first 10 total